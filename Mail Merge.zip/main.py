# TODO 1: Create a letter using Birthday.txt
# TODO 2: For each name in invited_names.txt
# TODO 3: Replace the [name] placeholder with the actual name.
# TODO 4: Save the letters in the folder "ReadyToSend".

import os


def create_letter(letter_directory, names_directory, author):
    letter_filename = os.path.splitext(os.path.basename(letter_directory))[0]

    with open(letter_directory) as letter:
        inside_letter = letter.read()

    with open(names_directory) as names:
        for name in names.readlines():
            name = name.strip("\n")
            new_letter = inside_letter.replace("[name]", name)
            new_letter = new_letter.replace("[author]", author)

            create_new_letter = open(f"Output/ReadyToSend/{letter_filename} letter from {author} to {name}.txt", "w")
            create_new_letter.write(new_letter)

    print("Letters created.")


# create_letter("Input/Letters/Birthday.txt", "Input/Names/invited_names.txt", "Radek")

create_letter(input("Sample letter path: "), input("Names path: "), input("Author name: "))
