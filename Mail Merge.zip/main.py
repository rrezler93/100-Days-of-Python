import os

def create_letter(letter_directory, names_directory, author):
    letter_filename = os.path.splitext(os.path.basename(letter_directory))[0]

    with open(letter_directory) as letter:
        inside_letter = letter.read()

    with open(names_directory) as names:
        while True:
            name = names.readline()
            if not name:
                break

            new_letter = inside_letter.replace("[name]", name.strip())
            new_letter = new_letter.replace("[author]", author)

            name_only = name.split()[-1]
            create_new_letter = open(f"Output/ReadyToSend/{letter_filename} letter from {author} to {name_only}.txt", "w")
            create_new_letter.write(new_letter)
            create_new_letter.close()

    print("Letters created.")

# create_letter("Input/Letters/Birthday.txt", "Input/Names/invited_names.txt", "Radek")

create_letter(input("Sample letter path: "), input("Names path: "), input("Author name: "))